searchApp.controller('searchCtrl', Ctrl1);
Ctrl1.$inject = [ 'DataService', 'ngAudio'];

function Ctrl1(DataService, ngAudio){
    var vm = this;

    vm.setAudio = function(url){
        vm.audio = ngAudio.load(url);
        return vm.audio;
    };
    
    vm.search = {
      keyword: '',
      limit: 10,
      result: [],
      error: null
    };

    vm.favorites = [];
    vm.favoriteIds = [];

    vm.query = function() {

      vm.isActive = true;
      DataService.query(vm.search.keyword, vm.search.limit).
        success(function(data){
          vm.search.result = data;
        })
    };

    vm.get = function(){
        vm.isActive = false;
        DataService.get().
            success(function(response){
                vm.favorites.length = 0;
                for(i=0; i<response.length; i++ ){
                    var favoriteData = {
                        "id" : response[i].id,
                        "trackName" : response[i].itunes_data.trackName,
                        "artistName" : response[i].itunes_data.artistName,
                        "trackPrice" : response[i].itunes_data.trackPrice,
                        "image" : response[i].itunes_data.artworkUrl100,
                        "trackId" : response[i].itunes_data.trackId,
                        "previewUrl" : response[i].itunes_data.previewUrl
                    };
                    vm.favorites.push(favoriteData);
                }
            });
    };

    vm.post = function(param) {
      DataService.post(param);
      vm.favoriteIds.push(param.trackId);
    };

    vm.del = function(id,index, trackId) {
      DataService.del(id);
      vm.favorites.splice(index,1);
      var removeIndex = vm.favoriteIds.indexOf(trackId);
      if(removeIndex > -1){
        vm.favoriteIds.splice(removeIndex, 1);
      }
      
    };

    vm.show = function(trackId){
        return vm.favoriteIds.indexOf(trackId) < 0 ? false : true;
    };
}
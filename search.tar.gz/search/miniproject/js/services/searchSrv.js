searchApp.factory('DataService', DataService);
DataService.$inject = ['$http']

function DataService($http){
	var query = function(keyword, limit) {
	  var URL = 'https://itunes.apple.com/search';
	  return $http.jsonp(URL, {
	    params: {
	        "callback": "JSON_CALLBACK",
	        "term": keyword,
	        "limit": limit || 10
	    }
	  });
	};
	var post = function(data) {
	  var URL = 'http://cs-itunes.appspot.com/api/favorite/jasmin.caronan@cloudsherpas.com';
	  return $http.post(URL, data);
	};

	var get = function() {
		var URL = 'http://cs-itunes.appspot.com/api/favorite/jasmin.caronan@cloudsherpas.com';
		return $http.get(URL);
	};

	var del = function(id) {
	  var URL = 'http://cs-itunes.appspot.com/api/favorite/jasmin.caronan@cloudsherpas.com/' + id;
	  return $http.delete(URL);
	};

	return {
	  query: query,
	  post: post,
	  get: get,
	  del: del
	}

}
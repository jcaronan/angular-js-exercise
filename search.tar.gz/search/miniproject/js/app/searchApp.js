'use strict';

// Declare app level module which depends on views, and components
var searchApp = angular.module('searchApp', ['ngAudio', 'ui.bootstrap']);

